package com.demo.Dmario_jeans;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DmarioJeansApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmarioJeansApplication.class, args);
	}

}
